const nav = document.querySelector('#nav');
const navBtn = document.querySelector('#nav-btn');
const navBtnImg = document.querySelector('#nav-btn-img');

navBtn.onclick = () => {
  if(nav.classList.toggle('open')){
    navBtnImg.src = "./img/icons/nav-close.svg";
  } else {
    navBtnImg.src = "./img/icons/nav-open.svg";
  }
}

AOS.init({
  // отключам анимации всё мобилной устроетсве
  // disable: 'mobile',

  // отключам анимации только мобилной 
  //disable: 'phone',

  // отключам анимации
  // once: true, 
})
